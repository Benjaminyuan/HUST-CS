#include <iostream>
struct STACK
{
    int *elems; //申请内存用于存放栈的元素
    int max;    //栈能存放的最大元素个数
    int pos;    //栈实际已有元素个数，栈空时pos=0;
};
void initSTACK(STACK *const p, int m);               //初始化p指向的栈：最多m个元素
void initSTACK(STACK *const p, const STACK &s);      //用栈s初始化p指向的栈
int size(const STACK *const p);                      //返回p指向的栈的最大元素个数max
int howMany(const STACK *const p);                   //返回p指向的栈的实际元素个数pos
int getelem(const STACK *const p, int x);            //取下标x处的栈元素
STACK *const push(STACK *const p, int e);            //将e入栈，并返回p
STACK *const pop(STACK *const p, int &e);            //出栈到e，并返回p
STACK *const assign(STACK *const p, const STACK &s); //赋s给p指的栈,并返回p
void print(const STACK *const p);                    //打印p指向的栈
void destroySTACK(STACK *const p);                   //销毁p指向的栈

void initSTACK(STACK *const p, int m)
{
    p->elems = new int[m];
    p->max = m;
    p->pos = 0;
}

void initSTACK(STACK *const p, const STACK &s)
{
    p->elems = new int[s.max];
    p->pos = s.pos;
    for (int i = 0; i < s.pos; ++i)
        p->elems[i] = s.elems[i];
}

int size(const STACK *const p)
{
    return p->max;
}

int howMany(const STACK *const p)
{
    return p->pos;
}

int getelem(const STACK *const p, int x)
{
    if (x >= p->max)
        throw std::logic_error("index overflow");
    return p->elems[x];
}

STACK *const push(STACK *const p, int e)
{
    if (p->pos == p->max)
        throw std::logic_error("push: stack size not enough");
    p->elems[p->pos] = e;
    ++p->pos;
    return p;
}

STACK *const pop(STACK *const p, int &e)
{
    if (p->pos == 0)
        throw std::logic_error("pop: pop from a empty stack");
    e = p->elems[--p->pos];
    return p;
}

STACK *const assign(STACK *const p, const STACK &s)
{
    p->pos = s.pos;
    p->max = s.max;
    delete p->elems;
    p->elems = new int[p->pos];
    for (int i = 0; i < s.pos; ++i){
        p->elems[i] = s.elems[i];
    }
    return p;
}
void print(const STACK *const p)
{
    for (int i = 0; i < p->pos; ++i)
    {
        std::cout << p->elems[i];
    }
    std::cout << std::flush;
}
void destroySTACK(STACK *const p)
{
    delete[] p->elems;
    p->elems = nullptr;
    p->pos = 0;
    p->max = 0;
}