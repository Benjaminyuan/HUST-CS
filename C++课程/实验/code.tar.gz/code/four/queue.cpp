#include"../second/stack.h"
#include<iostream>
class QUEUE : public STACK {
private:
    STACK s2;

public:
    QUEUE(int m);
    QUEUE(const QUEUE &s);
    virtual operator int() const;
    virtual int full() const;
    virtual int operator[](int x)const;
    virtual QUEUE &operator<<(int e);
    virtual QUEUE &operator>>(int &e);
    virtual QUEUE &operator=(const QUEUE &s);
    virtual void print() const;
    virtual ~QUEUE();
};
QUEUE::QUEUE(int m) : STACK(m), s2(m) {
    return;
}

QUEUE::QUEUE(const QUEUE &s) : STACK(static_cast<STACK>(s)), s2(s.s2) {
    return;
}

QUEUE::operator int() const {
    return STACK::operator int() + s2.operator int();
}

int QUEUE::full() const {
    return STACK::operator int() == STACK::size() && !s2.operator int();
}

int QUEUE::operator [](int x) const {
    if (x >= STACK::operator int() + s2.operator int())
        throw std::logic_error("trying to get elem outside of queue");
    if (x >= int(s2))
        return STACK::operator [](x - int(s2));
    else
        return s2[int(s2) - x - 1];
}

QUEUE &QUEUE::operator <<(int e) {
    if (STACK::operator int() == STACK::size()) {
        int temp;
        int origSize = STACK::operator int();
        for (int i = 0; i < origSize; ++i) {
            STACK::operator >>(temp);
            s2 << temp;
        }
    }
    STACK::operator <<(e);
    return *this;
}

QUEUE &QUEUE::operator >>(int &e) {
    if (int(s2)) {
        s2 >> e;
    } else {
        int temp;
        int origSize = STACK::operator int();
        for (int i = 0; i < origSize - 1; ++i) {
            STACK::operator >>(temp);
            s2 << temp;
        }
        STACK::operator >>(e);
    }
    return *this;
}

QUEUE &QUEUE::operator =(const QUEUE &s) {
    STACK::operator=(static_cast<STACK>(s));
    s2 = s.s2;
    return *this;
}

void QUEUE::print() const {
    using namespace std;

    for (int i = 0; i < int(s2); i++) {
        cout << s2[int(s2) - i - 1];
    }

    for (int i = 0; i < STACK::operator int(); i++) {
        cout << STACK::operator [](i);
    }
    cout << flush;
}
QUEUE::~QUEUE() {
    return;
}