#include"../second/stack.h"
#include<iostream>
class QUEUE{
    STACK s1, s2;
public:
QUEUE(int m); //每个栈最多m个元素，要求实现的队列最多能入2m个元素
QUEUE(const QUEUE&q); 			//用队列q拷贝初始化队列
QUEUE(QUEUE &&q);				//移动构造
virtual operator int ( ) const;			//返回队列的实际元素个数
virtual int full ( ) const;		       //返回队列是否已满，满返回1，否则返回0
virtual int operator[ ](int x)const;   //取下标为x的元素,第1个元素下标为0
virtual QUEUE& operator<<(int e); 	//将e入队列,并返回队列
virtual QUEUE& operator>>(int &e);	//出队列到e,并返回队列
virtual QUEUE& operator=(const QUEUE&q); //赋q给队列,并返回被赋值的队列
virtual QUEUE& operator=(QUEUE&&q);	//移动赋值
virtual void print( ) const;			//打印队列
virtual ~QUEUE( );					//销毁队列
};
QUEUE::QUEUE(int m):s1(m),s2(m){

}
QUEUE::QUEUE(const QUEUE&q):s1(q.s1),s2(q.s2){
} 			//用队列q拷贝初始化队列
QUEUE::QUEUE(QUEUE &&q):s1(q.s1),s2(q.s2){

}
QUEUE::operator int()const {
    return int(s1)+int(s2);
}
int QUEUE::full()const{
    return (int(s1) == s1.size) && !int(s2);
}
int QUEUE::operator[](int x)const{
    if (x >= int(s1) +int(s2)){
        throw std::logic_error("index out of range");        
    }
    if(x >= int(s2)){
        return s1[x - int(s2)];
    }else{
        return s2[int(s2) - x - 1];
    }
}
QUEUE& QUEUE::operator<<(int e){
    if(int(s1) == s1.size){
        int temp;
        for(int i=0;i<int(s1);i++){
            s1 >> temp;
            s2 << temp;
        }
    }
    s1 << e;
    return *this;
}
QUEUE& QUEUE::operator>>(int &e){
    if(int(s2)){
        s2 >> e;
        return *this;
    }
    int temp ;
    for(int i=0;i<int(s1);i++){
        s1 >> temp;
        s2 << temp;
    }
    s2 >> e;
    return *this;
}
QUEUE& QUEUE::operator =(const QUEUE &s) {
    s1 = s.s1;
    s2 = s.s2;
    return *this;
}
void QUEUE::print()const {
    using namespace std;
    for(int i = 0; i < int(s2); ++i){
        cout << s2[int(s2) - i - 1];
    }
    for(int i = 0; i < int(s1); ++i){
        cout << s1[i];
    }
    cout << flush;
}
QUEUE::~QUEUE(){
    return;
}